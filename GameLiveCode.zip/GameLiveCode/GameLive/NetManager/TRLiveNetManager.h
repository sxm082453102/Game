//
//  TRLiveNetManager.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CategoryModel.h"
#import "VideoModel.h"
#import "ADSlotModel.h"
#import "FastNewsModel.h"
#import "RoomModel.h"
#import "GameRoomModel.h"
#import "SearchModel.h"
#import "IntroModel.h"

@interface TRLiveNetManager : NSObject
/** 获取首页推荐页的数据 */
+ (id)getIntroCompletionHandler:(void(^)(IntroModel *introModel, NSError *error))completionHandler;

/** 获取房间列表 */
+ (id)getRoomListWithPage:(NSInteger)page completionHandler:(void(^)(RoomModel *model, NSError *error))completionHandler;

/** 获取直播列表 */
+ (id)getVideosCompletionHandler:(void(^)(VideoModel *model, NSError *error))completionHandler;

/** 获取栏目列表 */
+ (id)getCategoriesCompletionHandler:(void(^)(NSArray<CategoryModel *> *model, NSError *error))completionHandler;

+ (id)getADSlotCompletionHandler:(void(^)(ADSlotModel *model, NSError *error))completionHandler;

+ (id)getFastNewsCompletionHandler:(void(^)(FastNewsModel *model, NSError *error))completionHandler;

+ (id)getGameRoomModelWithSlug:(NSString *)slug page:(NSInteger)page completionHandler:(void(^)(GameRoomModel *model, NSError *error))completionHandler;

+ (id)search:(NSString *)words completionHandler:(void(^)(SearchModel *model, NSError *error))completionHandler;


@end







