//
//  TRLiveNetManager.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "TRLiveNetManager.h"

@implementation TRLiveNetManager
+ (id)getIntroCompletionHandler:(void (^)(IntroModel *, NSError *))completionHandler{
    return [self GET:@"http://www.quanmin.tv/json/page/app-index/info.json" parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([IntroModel parseJSON:responseObj], error);
    }];
}

+ (id)search:(NSString *)words completionHandler:(void (^)(SearchModel *, NSError *))completionHandler{
    NSMutableDictionary *params = [NSMutableDictionary new];
    [params setObject:@"site.search" forKey:@"m"];
    [params setObject:@"2" forKey:@"os"];
    [params setObject:@"0" forKey:@"p[categoryId]"];
    //防止words为空
    [params setObject:words ?: @"" forKey:@"p[key]"];
    [params setObject:@"0" forKey:@"p[page]"];
    [params setObject:@"10" forKey:@"p[size]"];
    [params setObject:@"1.3.2" forKey:@"v"];
    return [self POST:@"http://www.quanmin.tv/api/v1" parameters:params progress:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([SearchModel parseJSON:responseObj], error);
    }];
}


+ (id)getGameRoomModelWithSlug:(NSString *)slug page:(NSInteger)page completionHandler:(void (^)(GameRoomModel *, NSError *))completionHandler{
    NSString *path = [NSString stringWithFormat:@"http://www.quanmin.tv/json/categories/%@/list_%ld.json", slug, page];
    return [self GET:path parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([GameRoomModel parseJSON:responseObj], error);
    }];
}

+ (id)getRoomListWithPage:(NSInteger)page completionHandler:(void (^)(RoomModel *, NSError *))completionHandler{
    NSString *path = [NSString stringWithFormat:@"http://www.quanmin.tv/json/play/list_%ld.json", page];
    return [self GET:path parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([RoomModel parseJSON:responseObj], error);
    }];
}


+(id)getVideosCompletionHandler:(void (^)(VideoModel *, NSError *))completionHandler{
    return [self GET:@"http://c.m.163.com/nc/video/home/1-10.html" parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        //VideoModel *model = [VideoModel modelWithJSON:responseObj];
        completionHandler([VideoModel parseJSON:responseObj], error);
    }];
}

+ (id)getCategoriesCompletionHandler:(void (^)(NSArray<CategoryModel *> *model, NSError *))completionHandler{
    return [self GET:@"http://www.quanmin.tv/json/categories/list.json" parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
               !completionHandler ?: completionHandler([CategoryModel parseJSON:responseObj], error);
    }];
}

+ (id)getADSlotCompletionHandler:(void(^)(ADSlotModel *model, NSError *error))completionHandler{
    return [self GET:@"http://www.quanmin.tv/json/page/ad-slot/info.json" parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([ADSlotModel parseJSON:responseObj], error);
    }];
}

+ (id)getFastNewsCompletionHandler:(void (^)(FastNewsModel *, NSError *))completionHandler{
    return [self GET:@"http://app.api.autohome.com.cn/autov5.0.0/news/fastnewslist-pm1-b0-l0-s20-lastid0.json" parameters:nil progress:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandler([FastNewsModel parseJSON:responseObj], error);
    }];
}

@end











