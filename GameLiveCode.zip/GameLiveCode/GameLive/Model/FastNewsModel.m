//
//  FastNewsModel.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "FastNewsModel.h"

@implementation FastNewsModel

@end
@implementation FastNewsResultModel
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"list": [FastNewsListModel class]};
}
@end

@implementation FastNewsListModel
//id -> ID
//typename -> typeName
//typeid -> typeId
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"typeName":@"typename",
             @"typeId":@"typeid",
             @"ID":@"id"};
}

@end












