//
//  ADSlotModel.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PcBanner,List;
@interface ADSlotModel : NSObject


@property (nonatomic, strong) NSArray<PcBanner *> *playerguanggao;

@property (nonatomic, strong) NSArray *appad;

@property (nonatomic, strong) NSArray<PcBanner *> *pcbanner;

@property (nonatomic, strong) NSArray<List *> *list;

@property (nonatomic, strong) NSArray<PcBanner *> *pcbanner2;
@end

@interface PcBanner : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *subtitle;
//id -> ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *ext;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *fk;

@property (nonatomic, copy) NSString *thumb;

@property (nonatomic, copy) NSString *link;

@property (nonatomic, copy) NSString *create_at;

@property (nonatomic, assign) NSInteger slot_id;

@property (nonatomic, assign) NSInteger priority;

@end

@interface List : NSObject

@property (nonatomic, copy) NSString *slug;

@property (nonatomic, copy) NSString *name;

@end



