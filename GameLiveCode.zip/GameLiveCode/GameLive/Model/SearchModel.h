//
//  SearchModel.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SearchDataModel,SearchDataItemsModel;
@interface SearchModel : NSObject
@property (nonatomic, strong) SearchDataModel *data;
@property (nonatomic, assign) NSInteger code;
@end

@interface SearchDataModel : NSObject
//play_status -> playStatus
@property (nonatomic, assign) NSInteger playStatus;

@property (nonatomic, assign) NSInteger pageNb;

@property (nonatomic, strong) NSArray<SearchDataItemsModel *> *items;

@property (nonatomic, assign) NSInteger total;

@end

@interface SearchDataItemsModel : NSObject
//category_slug -> categorySlug
@property (nonatomic, copy) NSString *categorySlug;

@property (nonatomic, assign) NSString *uid;

@property (nonatomic, copy) NSString *nick;
//category_id -> categoryId
@property (nonatomic, assign) NSInteger categoryId;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *title;
//category_name -> categoryName
@property (nonatomic, copy) NSString *categoryName;

@property (nonatomic, copy) NSString *thumb;

@property (nonatomic, copy) NSString *view;

@end

