//
//  IntroModel.h
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>


@class IntroLinkModel, IntroListModel, IntroMobileModel;
@interface IntroModel : NSObject
//moblie_webgame -> moblieWebgame
@property (nonatomic, strong) NSArray<IntroMobileModel *> *moblieWebgame;
//moblie_minecraft -> moblieMinecraft
@property (nonatomic, strong) NSArray<IntroMobileModel *> *moblieMinecraft;
//mobile_tvgame -> mobileTVGame
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileTVGame;
//moblie_sport -> moblieSport
@property (nonatomic, strong) NSArray<IntroMobileModel *> *moblieSport;
//mobile_star -> mobileStar
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileStar;
//mobile_recommendation -> mobileRecommendation
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileRecommendation;
//mobile_index -> mobileIndex
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileIndex;
//mobile_lol -> mobileLOL
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileLOL;
//mobile_beauty -> mobileBeauty
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileBeauty;
//mobile_heartstone -> mobileHeartstone
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileHeartstone;
//moblie_blizzard -> moblieBlizzard
@property (nonatomic, strong) NSArray<IntroMobileModel *> *moblieBlizzard;

@property (nonatomic, strong) NSArray<IntroListModel *> *list;
//mobile_dota2 -> mobileDota2
@property (nonatomic, strong) NSArray<IntroMobileModel *> *mobileDota2;
//moblie_dnf -> moblieDNF
@property (nonatomic, strong) NSArray<IntroMobileModel *> *moblieDNF;

@end

@interface IntroLinkModel : NSObject

@property (nonatomic, copy) NSString *nick;
//weight_add -> weightAdd
@property (nonatomic, copy) NSString *weightAdd;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy) NSString *level;
//follow_add -> followAdd
@property (nonatomic, copy) NSString *followAdd;
@property (nonatomic, copy) NSString *slug;
@property (nonatomic, copy) NSString *check;
@property (nonatomic, copy) NSString *thumb;
//play_count -> playCount
@property (nonatomic, copy) NSString *playCount;
//negative_view -> negativeView
@property (nonatomic, copy) NSString *negativeView;
@property (nonatomic, copy) NSString *view;
@property (nonatomic, copy) NSString *grade;
@property (nonatomic, copy) NSString *coin;
//coin_add -> coinAdd
@property (nonatomic, copy) NSString *coinAdd;
//default_image -> defaultImage
@property (nonatomic, copy) NSString *defaultImage;
//create_at -> createAt
@property (nonatomic, copy) NSString *createAt;
@property (nonatomic, copy) NSString *intro;
//category_name -> categoryName
@property (nonatomic, copy) NSString *categoryName;
@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *avatar;
//recommend_image -> recommendImage
@property (nonatomic, copy) NSString *recommendImage;
//locked_view -> lockedView
@property (nonatomic, copy) NSString *lockedView;
//last_end_at -> lastEndAt
@property (nonatomic, copy) NSString *lastEndAt;
//video_quality -> videoQuality
@property (nonatomic, copy) NSString *videoQuality;
@property (nonatomic, copy) NSString *announcement;
//first_play_at -> firstPlayAt
@property (nonatomic, copy) NSString *firstPlayAt;
@property (nonatomic, copy) NSString *follow;
//follow_bak -> followBak
@property (nonatomic, copy) NSString *followBak;
//play_at -> playAt
@property (nonatomic, copy) NSString *playAt;
@property (nonatomic, copy) NSString *weight;
//app_shuffling_image -> appShufflingImage
@property (nonatomic, copy) NSString *appShufflingImage;
//category_id -> categoryID
@property (nonatomic, copy) NSString *categoryID;
@property (nonatomic, copy) NSString *title;
//category_slug -> categorySlug
@property (nonatomic, copy) NSString *categorySlug;
@end

@interface IntroMobileModel : NSObject
//id -> ID
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *thumb;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *subtitle;
//slot_id -> slotID
@property (nonatomic, assign) NSInteger slotID;
@property (nonatomic, copy) NSString *link;
@property (nonatomic, assign) NSInteger priority;
@property (nonatomic, copy) NSString *title;
//create_at -> createAt
@property (nonatomic, copy) NSString *createAt;
// link_object -> linkObject
@property (nonatomic, strong) IntroLinkModel *linkObject;
@property (nonatomic, copy) NSString *ext;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, copy) NSString *fk;

@end

@interface IntroListModel : NSObject
@property (nonatomic, copy) NSString *slug;
@property (nonatomic, copy) NSString *name;
@end




