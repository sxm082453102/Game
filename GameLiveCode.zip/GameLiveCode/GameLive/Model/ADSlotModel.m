//
//  ADSlotModel.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "ADSlotModel.h"
@implementation ADSlotModel
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"playerguanggao":[PcBanner class],
             @"pcbanner":[PcBanner class],
             @"list": [List class],
             @"pcbanner2": [PcBanner class]};
}

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"playerguanggao": @"player-guanggao",
             @"pcbanner": @"pc-banner",
             @"pcbanner2": @"pc-banner2"};
}
@end

@implementation PcBanner
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"ID": @"id"};
}

@end
@implementation List

@end









