//
//  FastNewsModel.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FastNewsResultModel,FastNewsListModel;
@interface FastNewsModel : NSObject


@property (nonatomic, strong) FastNewsResultModel *result;

@property (nonatomic, assign) NSInteger returncode;

@property (nonatomic, copy) NSString *message;


@end
@interface FastNewsResultModel : NSObject

@property (nonatomic, assign) BOOL isloadmore;

@property (nonatomic, assign) NSInteger rowcount;

@property (nonatomic, strong) NSArray<FastNewsListModel *> *list;

@end

@interface FastNewsListModel : NSObject
//id -> ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger state;
//typename -> typeName
@property (nonatomic, copy) NSString *typeName;

@property (nonatomic, copy) NSString *createtime;

@property (nonatomic, copy) NSString *lastid;

@property (nonatomic, copy) NSString *advancetime;

@property (nonatomic, copy) NSString *bgimage;

@property (nonatomic, assign) NSInteger reviewcount;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *publishtiptime;
//typeid -> typeId
@property (nonatomic, assign) NSInteger typeId;

@end

