//
//  SearchModel.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "SearchModel.h"

@implementation SearchModel

@end
@implementation SearchDataModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"items":[SearchDataItemsModel class]};
}

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{@"playStatus": @"play_status"};
}

@end

@implementation SearchDataItemsModel
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{@"categoryName": @"category_name",
             @"categoryId": @"category_id",
             @"categorySlug": @"category_slug"};
}
@end


