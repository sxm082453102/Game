//
//  RoomModel.h
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RoomDataModel;
@interface RoomModel : NSObject

@property (nonatomic, assign) NSInteger page;
@property (nonatomic, assign) NSInteger size;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, strong) NSArray<RoomDataModel *> *data;
@property (nonatomic, assign) NSInteger total;
@property (nonatomic, assign) NSInteger pageCount;

@end

@interface RoomDataModel : NSObject

@property (nonatomic, copy) NSString *nick;
//weight_add -> weightAdd
@property (nonatomic, copy) NSString *weightAdd;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy) NSString *level;
//follow_add -> followAdd
@property (nonatomic, copy) NSString *followAdd;
@property (nonatomic, copy) NSString *slug;
@property (nonatomic, copy) NSString *check;
@property (nonatomic, copy) NSString *thumb;
//play_count -> playCount
@property (nonatomic, copy) NSString *playCount;
//negative_view -> negativeView
@property (nonatomic, copy) NSString *negativeView;
@property (nonatomic, copy) NSString *view;
@property (nonatomic, copy) NSString *grade;
@property (nonatomic, copy) NSString *coin;
//coin_add -> coinAdd
@property (nonatomic, copy) NSString *coinAdd;
//default_image -> defaultImage
@property (nonatomic, copy) NSString *defaultImage;
//create_at -> createAt
@property (nonatomic, copy) NSString *createAt;
@property (nonatomic, copy) NSString *intro;
//category_name -> categoryName
@property (nonatomic, copy) NSString *categoryName;
@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *avatar;
//recommend_image -> recommendImage
@property (nonatomic, copy) NSString *recommendImage;
//locked_view -> lockedView
@property (nonatomic, copy) NSString *lockedView;
//last_end_at -> lastEndAt
@property (nonatomic, copy) NSString *lastEndAt;
//video_quality -> videoQuality
@property (nonatomic, copy) NSString *videoQuality;
@property (nonatomic, copy) NSString *announcement;
//first_play_at -> firstPlayAt
@property (nonatomic, copy) NSString *firstPlayAt;
@property (nonatomic, assign) NSInteger follow;
//follow_bak -> followBak
@property (nonatomic, copy) NSString *followBak;
//play_at -> playAt
@property (nonatomic, copy) NSString *playAt;
@property (nonatomic, copy) NSString *weight;
//app_shuffling_image -> appShufflingImage
@property (nonatomic, copy) NSString *appShufflingImage;
//category_id -> categoryId
@property (nonatomic, copy) NSString *categoryId;
@property (nonatomic, copy) NSString *title;
//category_slug -> categorySlug
@property (nonatomic, copy) NSString *categorySlug;

@end

