//
//  CategoryModel.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "CategoryModel.h"

@implementation CategoryModel
//重写方法,来配置修改的属性名和key的对应关系
//返回一个 Dict，将 Model 属性名对映射到 JSON 的 Key。
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"ID": @"id",
             @"firstLetter": @"first_letter",
             @"属性名": @"key"};
}
@end











