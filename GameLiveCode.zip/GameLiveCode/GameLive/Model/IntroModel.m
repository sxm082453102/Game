//
//  IntroModel.m
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "IntroModel.h"

@implementation IntroModel
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"moblieWebgame": [IntroMobileModel class],
             @"moblieMinecraft": [IntroMobileModel class],
             @"mobileTVGame": [IntroMobileModel class],
             @"moblieSport": [IntroMobileModel class],
             @"mobileStar": [IntroMobileModel class],
             @"mobileRecommendation": [IntroMobileModel class],
             @"mobileIndex": [IntroMobileModel class],
             @"mobileLOL": [IntroMobileModel class],
             @"mobileBeauty": [IntroMobileModel class],
             @"mobileHeartstone": [IntroMobileModel class],
             @"moblieBlizzard": [IntroMobileModel class],
             @"mobileDota2": [IntroMobileModel class],
             @"moblieDNF": [IntroMobileModel class],
             @"list": [IntroListModel class],};
}

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{@"moblieWebgame": @"moblie-webgame",
             @"moblieMinecraft": @"moblie-minecraft",
             @"mobileTVGame": @"mobile-tvgame",
             @"moblieSport": @"moblie-sport",
             @"mobileStar": @"mobile-star",
             @"mobileRecommendation": @"mobile-recommendation",
             @"mobileIndex": @"mobile-index",
             @"mobileLOL": @"mobile-lol",
             @"mobileBeauty": @"mobile-beauty",
             @"mobileHeartstone": @"mobile-heartstone",
             @"moblieBlizzard": @"moblie-blizzard",
             @"mobileDota2": @"mobile-dota2",
             @"moblieDNF": @"moblie-dnf"};
}

@end

@implementation IntroListModel

@end

@implementation IntroMobileModel

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{@"ID": @"id",
             @"slotID": @"slot_id",
             @"createAt": @"create_at",
             @"linkObject": @"link_object"};
}
@end

@implementation IntroLinkModel
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{@"weightAdd": @"weight_add",
             @"followAdd": @"follow_add",
             @"playCount": @"play_count",
             @"negativeView": @"negative_view",
             @"coinAdd": @"coin_add",
             @"defaultImage": @"default_image",
             @"createAt": @"create_at",
             @"categoryName": @"category_name",
             @"recommendImage": @"recommend_image",
             @"lockedView": @"locked_view",
             @"lastEndAt": @"last_end_at",
             @"videoQuality": @"video_quality",
             @"firstPlayAt": @"first_play_at",
             @"followBak": @"follow_bak",
             @"playAt": @"play_at",
             @"appShufflingImage": @"app_shuffling_image",
             @"categoryID": @"category_id",
             @"categorySlug": @"category_slug",
             };
}

@end









