//
//  CategoryModel.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CategoryModel : NSObject
//first_letter ->firstLetter
@property (nonatomic, copy) NSString *firstLetter;
@property (nonatomic, assign) NSInteger prompt;
@property (nonatomic, copy) NSString *slug;
//id -> ID
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *thumb;
@property (nonatomic, copy) NSString *name;

@end












