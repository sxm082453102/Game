//
//  AppDelegate.h
//  GameLive
//
//
//  
//




@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@end
#import "AppDelegate+Custom.h"








