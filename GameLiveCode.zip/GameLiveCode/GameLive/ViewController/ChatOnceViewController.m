//
//  ChatOnceViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/14.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "ChatOnceViewController.h"
#import "ConversationListController.h"
#import "AddFriendViewController.h"
#import "ContactListViewController.h"

@interface ChatOnceViewController ()
@end
@implementation ChatOnceViewController
- (void)viewDidLoad {
    [super viewDidLoad];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            ConversationListController *vc = [ConversationListController new];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 1) {
            ContactListViewController *vc = [ContactListViewController new];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 2) {
            AddFriendViewController *vc = [AddFriendViewController new];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
}


@end





