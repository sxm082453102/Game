//
//  SearchViewController.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchViewModel.h"
#import "RoomCell.h"

@interface SearchViewController ()<UISearchBarDelegate, UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic) UISearchBar *searchBar;
@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) SearchViewModel *searchVM;
@end

@implementation SearchViewController
#pragma mark - UICollectionView Delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [Tool playVideoInURL:[self.searchVM videoURLForIndex:indexPath.row]];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.searchVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    RoomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RoomCell" forIndexPath:indexPath];
    [cell.iconIV setImageURL:[self.searchVM iconURLForIndex:indexPath.row]];
    cell.titleLb.text = [self.searchVM titleForIndex:indexPath.row];
    cell.viewsLb.text = [self.searchVM viewsForIndex:indexPath.row];
    cell.nickLb.text = [self.searchVM nameForIndex:indexPath.row];
    return cell;
}

#pragma mark - UISearchBar Delegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    //键盘上的搜索按钮被点击时触发的
    NSString *words = searchBar.text;
    //..进行搜索操作....
    [self searchWithWords:words];
}

#pragma mark - 懒加载
- (UISearchBar *)searchBar{
    if (!_searchBar) {
        _searchBar = [UISearchBar new];
        _searchBar.placeholder = @"请输入关键词搜索";
        _searchBar.delegate = self;
    }
    return _searchBar;
}
#pragma mark - 生命周期
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.titleView = self.searchBar;
    [Tool addBackItemToVC:self];
    [Tool addSearchItemToVC:self clickedHandler:^{
        //点击搜索按钮后触发
        NSString *words = _searchBar.text;
        //..发搜索请求....
        [self searchWithWords:words];
    }];
    self.view.backgroundColor = [UIColor whiteColor];
    [self collectionView];
}

- (void)searchWithWords:(NSString *)words{
    [self.view showBusyHUD];
    [self.searchVM search:words completionHandler:^(NSError *error) {
        [_collectionView reloadData];
        [self.view hideBusyHUD];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 懒加载
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        //内边距 上下左右10
        layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
        //最小行间距10像素
        layout.minimumLineSpacing = 10;
        //最小列间距10像素
        layout.minimumInteritemSpacing = 10;
        //cell的大小
        CGFloat width = (kScreenW - 3*10) /2;
        CGFloat height = width / 175 * 133;
        layout.itemSize = CGSizeMake(width, height);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerNib:[UINib nibWithNibName:@"RoomCell" bundle:nil] forCellWithReuseIdentifier:@"RoomCell"];
        
    }
    return _collectionView;
}
- (SearchViewModel *)searchVM {
    if(_searchVM == nil) {
        _searchVM = [[SearchViewModel alloc] init];
    }
    return _searchVM;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
