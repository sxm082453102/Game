//
//  IntroViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/12.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "IntroViewController.h"
#import "IntroHeaderCell.h"
#import "IntroViewModel.h"
#import "RoomCell.h"
#import "IntroSectionHeaderView.h"
#import "SearchViewController.h"
#import "GameRoomViewController.h"

//最小行间距
#define kCellSpace   8
//每行显示的数量
#define kCellNumberPerLine  2

@interface IntroViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) IntroViewModel *introVM;
@end

@implementation IntroViewController
#pragma mark - UICollectionView Delegate
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    IntroSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"IntroSectionHeaderView" forIndexPath:indexPath];
    headerView.changeBtn.hidden = YES;
    headerView.moreBtn.hidden = YES;
    if (indexPath.section == 1) {
        headerView.titleLb.text = @"精彩推荐";
        headerView.changeBtn.hidden = NO;
        [headerView addClickedHandler:^{
            [self.introVM changeCurrentRecommendList];
            [self.collectionView reloadSections:[NSIndexSet indexSetWithIndex:1]];
        }];
    }
    if (indexPath.section > 1) {
        headerView.titleLb.text = [self.introVM linkCategoryNameForSection:indexPath.section - 2];
        headerView.moreBtn.hidden = NO;
        [headerView addClickedHandler:^{
            GameRoomViewController *vc = [[GameRoomViewController alloc] init];
            NSIndexPath *tmpIP = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section - 2];
            vc.slug = [self.introVM linkSlugForIndexPath:tmpIP];
            vc.title = [self.introVM linkCategoryNameForSection:indexPath.section - 2];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }];
    }
    return headerView;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    if (section != 0) {
        return CGSizeMake(kScreenW, 35);
    }
    return CGSizeZero;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1) { //推荐页
        [Tool playVideoInURL:[self.introVM recommendVideoURLForIndex:indexPath.row]];
    }
    if (indexPath.section > 1) { //其他
        NSIndexPath *tmpIP = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section - 2];
        [Tool playVideoInURL:[self.introVM linkVideoURLForIndexPath:tmpIP]];
    }
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.introVM.linkNumber + 2;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (section == 0) { //头部
        return 1;
    }
    if (section == 1) { //推荐
        return 2;
    }
    return [self.introVM linkNumberForSection:section-2];
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        IntroHeaderCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"IntroHeaderCell" forIndexPath:indexPath];
        cell.introVM = self.introVM;
        return cell;
    }else{
        RoomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RoomCell" forIndexPath:indexPath];
        if (indexPath.section == 1) { //推荐
            cell.titleLb.text = [self.introVM recommendTitleForIndex:indexPath.row];
            cell.viewsLb.text = [self.introVM recommendViewNumberForIndex:indexPath.row];
            cell.nickLb.text = [self.introVM recommendNickForIndex:indexPath.row];
            [cell.iconIV setImageWithURL:[self.introVM recommendIconURLForIndex:indexPath.row]];
        }else{
            NSIndexPath *tmpIP = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section - 2];
            cell.titleLb.text = [self.introVM linkTitleForIndexPath:tmpIP];
            cell.nickLb.text = [self.introVM linkNickForIndexPath:tmpIP];
            cell.viewsLb.text = [self.introVM linkViewForIndexPath:tmpIP];
            [cell.iconIV setImageWithURL:[self.introVM linkIconURLForIndexPath:tmpIP]];
        }
        return cell;
    }
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        //375 * 320
        return CGSizeMake(kScreenW, kScreenW/ 375 * 207 + 110);
    }
    CGFloat width = (kScreenW - (kCellNumberPerLine + 1) * kCellSpace) / kCellNumberPerLine;
    //175 * 137
    CGFloat height = width / 175 * 137;
    return CGSizeMake(width, height);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    if (section != 0) {
        return kCellSpace;
    }
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    if (section != 0) {
        return kCellSpace;
    }
    return 0;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    if (section != 0) {
        return UIEdgeInsetsMake(kCellSpace, kCellSpace, kCellSpace, kCellSpace);
    }
    return UIEdgeInsetsZero;
}


#pragma mark - 懒加载
- (IntroViewModel *)introVM{
    if (!_introVM) {
        _introVM = [IntroViewModel new];
    }
    return _introVM;
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [Tool addSearchItemToVC:self clickedHandler:^{
        SearchViewController *searchVC =[SearchViewController new];
        [self.navigationController pushViewController:searchVC animated:YES];
    }];
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"IntroHeaderCell" bundle:nil] forCellWithReuseIdentifier:@"IntroHeaderCell"];
    [self.collectionView registerNib:[UINib nibWithNibName:@"RoomCell" bundle:nil] forCellWithReuseIdentifier:@"RoomCell"];
    [self.collectionView registerNib:[UINib nibWithNibName:@"IntroSectionHeaderView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"IntroSectionHeaderView"];
    
    
    [self.collectionView tr_addHeaderRefresh:^{
       [self.introVM getDataCompletionHandler:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView tr_endHeaderRefresh];
       }];
    }];
    [self.collectionView tr_beginHeaderRefresh];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
