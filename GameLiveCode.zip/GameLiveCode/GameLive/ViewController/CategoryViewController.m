//
//  CategoryViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "CategoryViewController.h"
#import "CategoryViewModel.h"
#import "CategoryCell.h"
#import "GameRoomViewController.h"
#import "SearchViewController.h"

@interface CategoryViewController ()<UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) CategoryViewModel *categoryVM;
@end

@implementation CategoryViewController

#pragma mark - UICollectionView Delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

    //GameRoomViewController *vc = [GameRoomViewController new];
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    GameRoomViewController *vc = [sb instantiateViewControllerWithIdentifier:@"GameRoomViewController"];
    //传入参数
    vc.slug = [self.categoryVM slugForIndex:indexPath.row];
    //push操作时, 隐藏下方的tabbar
    vc.hidesBottomBarWhenPushed = YES;
    //设置新页面的导航栏题目
    vc.title = [self.categoryVM titleForIndex:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.categoryVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CategoryCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CategoryCell" forIndexPath:indexPath];
    cell.titleLb.text = [self.categoryVM titleForIndex:indexPath.row];
    [cell.iconIV setImageURL:[self.categoryVM iconURLForIndex:indexPath.row]];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = (kScreenW - 4 * 10) / 3;
    //115 * 190
    CGFloat height = width / 115 * 190;
    return CGSizeMake(width, height);
}

#pragma mark - 懒加载
- (CategoryViewModel *)categoryVM{
    if (!_categoryVM) {
        _categoryVM = [CategoryViewModel new];
    }
    return _categoryVM;
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [Tool addSearchItemToVC:self clickedHandler:^{
        SearchViewController *vc = [SearchViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    }];
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"CategoryCell" bundle:nil] forCellWithReuseIdentifier:@"CategoryCell"];
    [self.view showBusyHUD];
    [self.categoryVM getDataCompletionHandler:^(NSError *error) {
        [self.view hideBusyHUD];
        [self.collectionView reloadData];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
