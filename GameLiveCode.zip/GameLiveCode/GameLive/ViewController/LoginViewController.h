//
//  LoginViewController.h
//  GameLive
//
//  Created by shixiaomin on 16/4/13.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UITableViewController

@end
