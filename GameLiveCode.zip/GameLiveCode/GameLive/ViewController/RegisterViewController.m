//
//  RegisterViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/13.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "RegisterViewController.h"
#import <SMS_SDK/SMSSDK.h>

@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;
@property (weak, nonatomic) IBOutlet UITextField *validCodeTF;
@end
@implementation RegisterViewController
#pragma mark - 方法
- (IBAction)registerBtnClicked:(UIButton *)sender {
    NSString *userName = _userNameTF.text;
    NSString *password = _passwordTF.text;
    NSString *code = _validCodeTF.text;
    if (userName.stringByTrim.length == 11 && password.stringByTrim.length > 0 && code.stringByTrim.length > 0) {
        //TODO: 注册操作
        //到<环信>注册账号
        [self.view showBusyHUD];
        [SMSSDK commitVerificationCode:code phoneNumber:userName zone:@"86" result:^(NSError *error) {
            [self.view hideBusyHUD];
            if (error) {
                [self.view showWarning:@"验证码不正确"];
            }else{
                EMError *error = [[EMClient sharedClient] registerWithUsername:userName password:password.md5String];
                if (error==nil) {
                    [self.view showWarning:@"注册成功"];
                    NSLog(@"注册成功");
                }else{
                    [self.view showWarning:error.errorDescription];
                }
            }
        }];
    }else{
        [self.view showWarning:@"信息填写不正确"];
    }
}

- (IBAction)validCodeBtnClicked:(UIButton *)sender {
    NSString *userName = _userNameTF.text;
    if (userName.stringByTrim.length != 11) {
        [self.view showWarning:@"请输入正确的手机号码"];
        return;
    }
    [self.view showBusyHUD];
    [SMSSDK getVerificationCodeByMethod:SMSGetCodeMethodSMS phoneNumber:userName zone:@"86" customIdentifier:nil result:^(NSError *error) {
        [self.view hideBusyHUD];
        if (error) {
            [self.view showWarning:error.localizedDescription];
        }else{
            [self.view showWarning:@"短信验证码获取成功"];
            sender.enabled = NO;
            __block int duration = 60;
            [NSTimer bk_scheduledTimerWithTimeInterval:1 block:^(NSTimer *timer) {
                --duration;
                if (duration == 0) {
                    [timer invalidate];
                    timer = nil;
                    [sender setTitle:@"获取验证码" forState:UIControlStateNormal];
                    sender.enabled = YES;
                }
                [sender setTitle:@(duration).stringValue forState:UIControlStateNormal];
            } repeats:YES];
        }
    }];
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
}
@end
