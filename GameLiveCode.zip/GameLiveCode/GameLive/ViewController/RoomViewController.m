//
//  RoomViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "RoomViewController.h"
#import "RoomViewModel.h"
#import "RoomCell.h"

@interface RoomViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) RoomViewModel *roomVM;
@end

@implementation RoomViewController
#pragma mark - UICollectionView Delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [Tool playVideoInURL:[self.roomVM videoURLForIndex:indexPath.row]];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.roomVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    RoomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RoomCell" forIndexPath:indexPath];
    NSInteger row = indexPath.row;
    cell.titleLb.text = [self.roomVM titleForIndex:row];
    [cell.iconIV setImageURL:[self.roomVM iconURLForIndex:row]];
    cell.nickLb.text = [self.roomVM nameForIndex:row];
    cell.viewsLb.text = [self.roomVM viewsForIndex:row];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = (kScreenW - 3 * 10) / 2;
    //175 * 133
    CGFloat height = width / 175 * 133;
    return CGSizeMake(width, height);
}

#pragma mark - 方法

#pragma mark - 懒加载
- (RoomViewModel *)roomVM {
    if(_roomVM == nil) {
        _roomVM = [[RoomViewModel alloc] init];
    }
    return _roomVM;
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.collectionView registerNib:[UINib nibWithNibName:@"RoomCell" bundle:nil] forCellWithReuseIdentifier:@"RoomCell"];
        [_collectionView tr_addHeaderRefresh:^{
        [self.roomVM getRoomListWithReqeustMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [_collectionView reloadData];
            [_collectionView tr_endHeaderRefresh];
        }];
    }];
    [_collectionView tr_beginHeaderRefresh];
   
    [_collectionView tr_addFooterBackRefresh:^{
        [self.roomVM getRoomListWithReqeustMode:RequestModeMore completionHandler:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView tr_endFooterRefresh];
        }];
    }];
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
