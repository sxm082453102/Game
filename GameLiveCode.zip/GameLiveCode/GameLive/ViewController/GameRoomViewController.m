//
//  GameRoomViewController.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "GameRoomViewController.h"
#import "RoomCell.h"
#import "GameRoomViewModel.h"

@interface GameRoomViewController ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) GameRoomViewModel *gameRoomVM;
@end

@implementation GameRoomViewController
#pragma mark - UICollectionView Delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [Tool playVideoInURL:[self.gameRoomVM videoURLForIndex:indexPath.row]];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.gameRoomVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    RoomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RoomCell" forIndexPath:indexPath];
    [cell.iconIV setImageURL:[self.gameRoomVM iconURLForIndex:indexPath.row]];
    cell.titleLb.text = [self.gameRoomVM titleForIndex:indexPath.row];
    cell.viewsLb.text = [self.gameRoomVM viewsForIndex:indexPath.row];
    cell.nickLb.text = [self.gameRoomVM nameForIndex:indexPath.row];
    return cell;
}

#pragma mark - 懒加载
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        //内边距 上下左右10
        layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
        //最小行间距10像素
        layout.minimumLineSpacing = 10;
        //最小列间距10像素
        layout.minimumInteritemSpacing = 10;
        //cell的大小
        CGFloat width = (kScreenW - 3*10) /2;
        CGFloat height = width / 175 * 133;
        layout.itemSize = CGSizeMake(width, height);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        [_collectionView tr_addHeaderRefresh:^{
            [self.gameRoomVM getGameRoomModeWithRequestMode:RequestModeRefresh slug:_slug completionHandler:^(NSError *error) {
                [_collectionView reloadData];
                [_collectionView tr_endHeaderRefresh];
            }];
        }];
        
        [_collectionView tr_addFooterBackRefresh:^{
            [self.gameRoomVM getGameRoomModeWithRequestMode:RequestModeMore slug:_slug completionHandler:^(NSError *error) {
                [_collectionView reloadData];
                [_collectionView tr_endFooterRefresh];
            }];
        }];
        
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerNib:[UINib nibWithNibName:@"RoomCell" bundle:nil] forCellWithReuseIdentifier:@"RoomCell"];
        
    }
    return _collectionView;
}

- (GameRoomViewModel *)gameRoomVM{
    if (!_gameRoomVM) {
        _gameRoomVM = [GameRoomViewModel new];
    }
    return _gameRoomVM;
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.collectionView tr_beginHeaderRefresh];
    [Tool addBackItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
