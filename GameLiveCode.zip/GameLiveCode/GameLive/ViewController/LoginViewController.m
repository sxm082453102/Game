//
//  LoginViewController.m
//  GameLive
//
//  Created by shixiaomin on 16/4/13.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;

@end

@implementation LoginViewController
#pragma mark - 方法
- (IBAction)dismissBtnClicked:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)loginBtnClicked:(id)sender {
    NSString *userName = _userNameTF.text;
    NSString *password = _passwordTF.text;
    //stringByTrim可以去掉字符串前后空格
    if (userName.stringByTrim.length == 11 && password.stringByTrim.length > 0) {
        //TODO: 登录操作
        EMError *error = [[EMClient sharedClient] loginWithUsername:userName password:password.md5String];
        if (!error) {
            [self.view showWarning:@"登录成功"];
            NSLog(@"登陆成功");
            [[EMClient sharedClient].options setIsAutoLogin:YES];
            [self dismissViewControllerAnimated:YES completion:nil];
        }else{
            [self.view showWarning:error.errorDescription];
        }
    }else{
        [self.view showWarning:@"用户名或密码填写不正确"];
    }
}

#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
}
@end


