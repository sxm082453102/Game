//
//  Constant.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

#import "AppDelegate.h"

#define kAppDelegate ((AppDelegate *)([UIApplication sharedApplication].delegate))

//假设传入的R = 100 + 60 ->(100+60)/255.0
#define kRGBColor(R,G,B,A) [UIColor colorWithRed:(R)/255.0 green:(G)/255.0 blue:(B)/255.0 alpha:A]

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

#endif /* Constant_h */








