//
//  RoomViewModel.m
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "GameRoomViewModel.h"

@implementation GameRoomViewModel

- (NSURL *)videoURLForIndex:(NSInteger)index{
    return [NSURL URLWithString:[NSString stringWithFormat:@"http://hls.quanmin.tv/live/%@/playlist.m3u8", self.roomList[index].uid]];
}


- (NSInteger)rowNumber{
    return self.roomList.count;
}

- (NSURL *)iconURLForIndex:(NSInteger)index{
    return [NSURL URLWithString:self.roomList[index].thumb];
}

- (NSString *)titleForIndex:(NSInteger)index{
    return self.roomList[index].title;
}

- (NSString *)nameForIndex:(NSInteger)index{
    return self.roomList[index].nick;
}

- (NSString *)viewsForIndex:(NSInteger)index{
    NSString *views = self.roomList[index].view;
    if (views.integerValue >= 10000) {
        views = [NSString stringWithFormat:@"%.1f万", views.integerValue / 10000.0];
    }
    return views;
}

- (NSMutableArray<GameRoomDataModel *> *)roomList{
    if (!_roomList) {
        _roomList = @[].mutableCopy;
    }
    return _roomList;
}


- (void)getGameRoomModeWithRequestMode:(RequestMode)requestMode slug:(NSString *)slug completionHandler:(void(^)(NSError *error))completionHandler{
    NSInteger tmpPage = 1;
    if (requestMode == RequestModeMore) {
        tmpPage = ++_pageNum;
    }
    [TRLiveNetManager getGameRoomModelWithSlug:slug page:tmpPage completionHandler:^(GameRoomModel *model, NSError *error) {
        if (!error) {
            _pageNum = tmpPage;
            if (requestMode == RequestModeRefresh) {
                [self.roomList removeAllObjects];
            }
            [self.roomList addObjectsFromArray:model.data];
        }
        !completionHandler ?: completionHandler(error);
    }];
}


@end











