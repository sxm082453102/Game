//
//  IntroViewModel.h
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TRLiveNetManager.h"

@interface IntroViewModel : NSObject
//根据UI来声明属性和方法

/*========== 头部滚动栏的属性和方法 =============*/
@property (nonatomic, readonly) NSInteger indexNumber;
@property (nonatomic) NSArray<IntroMobileModel *> *indexList;
- (NSURL *)indexIconForIndex:(NSInteger)index;
- (NSString *)indexTitleForIndex:(NSInteger)index;
/** 内容对应的直播地址 */
- (NSURL *)indexURLForIndex:(NSInteger)index;

/*========== 明星展示栏的属性和方法 =============*/
@property (nonatomic) NSArray<IntroMobileModel *> *starList;
@property (nonatomic, readonly) NSInteger starNumber;
- (NSString *)starNameForIndex:(NSInteger)index;
- (NSURL *)starIconURLForIndex:(NSInteger)index;
- (NSURL *)starVideoURLForIndex:(NSInteger)index;

/*========== 精彩推荐的属性和方法  ==============*/
@property (nonatomic, readonly) NSInteger recommendNumber;
@property (nonatomic) NSArray<IntroMobileModel *> *recommendList;
/** 昵称 */
- (NSString *)recommendNickForIndex:(NSInteger)index;
/** 视频链接地址 */
- (NSURL *)recommendVideoURLForIndex:(NSInteger)index;
/** 缩略图地址 */
- (NSURL *)recommendIconURLForIndex:(NSInteger)index;
/** 题目 */
- (NSString *)recommendTitleForIndex:(NSInteger)index;
/** 观看人数 */
- (NSString *)recommendViewNumberForIndex:(NSInteger)index;

/** 从总数据数组中抽取用于显示的内容 */
- (void)changeCurrentRecommendList;
@property (nonatomic) NSArray<IntroMobileModel *> *currentRecommendList;

/*========== 剩余数据的属性和方法  ==============*/
@property (nonatomic, readonly) NSInteger linkNumber;
@property (nonatomic) NSArray<NSArray<IntroMobileModel *> *> *linkList;
/** 分组名称 */
- (NSString *)linkCategoryNameForSection:(NSInteger)section;

/** 每个分组的cell数量 */
- (NSInteger)linkNumberForSection:(NSInteger)section;
/** 每个cell的图片 */
- (NSURL *)linkIconURLForIndexPath:(NSIndexPath *)indexPath;
- (NSString *)linkTitleForIndexPath:(NSIndexPath *)indexPath;
- (NSString *)linkNickForIndexPath:(NSIndexPath *)indexPath;
- (NSString *)linkViewForIndexPath:(NSIndexPath *)indexPath;
- (NSURL *)linkVideoURLForIndexPath:(NSIndexPath *)indexPath;
- (NSString *)linkCategoryNameForIndexPath:(NSIndexPath *)indexPath;
- (NSString *)linkSlugForIndexPath:(NSIndexPath *)indexPath;

//根据接口来声明属性和方法

- (void)getDataCompletionHandler:(void(^)(NSError *error))completionHandler;

@end












