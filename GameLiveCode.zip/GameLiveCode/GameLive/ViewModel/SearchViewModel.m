//
//  SearchViewModel.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "SearchViewModel.h"

@implementation SearchViewModel
- (NSURL *)videoURLForIndex:(NSInteger)index{
    return [NSURL URLWithString:[NSString stringWithFormat:@"http://hls.quanmin.tv/live/%@/playlist.m3u8", self.roomList[index].uid]];
}


- (NSInteger)rowNumber{
    return self.roomList.count;
}

- (NSURL *)iconURLForIndex:(NSInteger)index{
    return [NSURL URLWithString:self.roomList[index].thumb];
}

- (NSString *)titleForIndex:(NSInteger)index{
    return self.roomList[index].title;
}

- (NSString *)nameForIndex:(NSInteger)index{
    return self.roomList[index].nick;
}

- (NSString *)viewsForIndex:(NSInteger)index{
    NSString *views = self.roomList[index].view;
    if (views.integerValue >= 10000) {
        views = [NSString stringWithFormat:@"%.1f万", views.integerValue / 10000.0];
    }
    return views;
}

- (void)search:(NSString *)words completionHandler:(void (^)(NSError *))completionHandler{
    [TRLiveNetManager search:words completionHandler:^(SearchModel *model, NSError *error) {
        self.roomList = model.data.items;
        !completionHandler ?: completionHandler(error);
    }];
}
@end
