//
//  IntroViewModel.m
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "IntroViewModel.h"

@implementation IntroViewModel

- (void)getDataCompletionHandler:(void (^)(NSError *))completionHandler{
    [TRLiveNetManager getIntroCompletionHandler:^(IntroModel *introModel, NSError *error) {
        if (!error) {
            self.indexList = introModel.mobileIndex;
            self.starList = introModel.mobileStar;
            self.recommendList = introModel.mobileRecommendation;
            self.linkList = @[introModel.mobileLOL,
                              introModel.mobileDota2,
                              introModel.mobileBeauty,
                              introModel.mobileTVGame,
                              introModel.mobileHeartstone];
        }
        !completionHandler ?: completionHandler(error);
    }];
}
/*========= 头部滚动栏 ============*/
- (NSInteger)indexNumber{
    return self.indexList.count;
}
- (NSURL *)indexIconForIndex:(NSInteger)index{
//#warning 想一下如何简化字符串转化成URL的步骤
    //return [NSURL URLWithString:self.indexList[index].thumb];
    return self.indexList[index].thumb.tr_URL;
}

- (NSString *)indexTitleForIndex:(NSInteger)index{
    return self.indexList[index].title;
}

- (NSURL *)indexURLForIndex:(NSInteger)index{
   return self.indexList[index].linkObject.uid.tr_videoURL;
}

/*========= 明星头像滚动栏 ============*/
- (NSInteger)starNumber{
    return self.starList.count;
}
- (NSString *)starNameForIndex:(NSInteger)index{
    return self.starList[index].title;
}
- (NSURL *)starIconURLForIndex:(NSInteger)index{
    return self.starList[index].thumb.tr_URL;
}
- (NSURL *)starVideoURLForIndex:(NSInteger)index{
    return self.starList[index].linkObject.uid.tr_videoURL;
}
/*========= 推荐 ============*/
- (NSInteger)recommendNumber{
    return self.currentRecommendList.count;
}

- (NSArray<IntroMobileModel *> *)currentRecommendList{
    if (_currentRecommendList == nil) {
        if (self.recommendList.count == 1) {
            _currentRecommendList = @[self.recommendList[0]];
        }
        if (self.recommendList.count > 1) {
          _currentRecommendList = @[self.recommendList[0], self.recommendList[1]];
        }
    }
    return _currentRecommendList;
}

- (void)changeCurrentRecommendList{
    // 0 1 -> 2 3 -> 4 5 -> 6 0
    id obj = self.currentRecommendList.lastObject;
    if (self.recommendList.count <= 2) return;
    
    //获取当前显示的最后一个元素在总列表中的索引值
    NSInteger index = [self.recommendList indexOfObject:obj];
    id introM0 = [self getNextRecommend:index];
    NSInteger index1 = [self.recommendList indexOfObject:introM0];
    id introM1 = [self getNextRecommend:index1];
    self.currentRecommendList = @[introM0, introM1];
}
//获取数组的下一个元素
- (IntroMobileModel *)getNextRecommend:(NSInteger)index{
    // 0 1 2 3 4 ->传入3 总数5个 > 3+1 真
    // 0 1 2 3 4 ->传入4 总数5个 > 4+1 假
    if (self.recommendList.count > index + 1) {
        return self.recommendList[index + 1];
    }else{
        return self.recommendList.firstObject;
    }
}

- (NSString *)recommendTitleForIndex:(NSInteger)index{
    return self.recommendList[index].linkObject.title;
}

- (IntroMobileModel *)recommendModelForIndex:(NSInteger)row{
    return self.currentRecommendList[row];
}

- (NSURL *)recommendIconURLForIndex:(NSInteger)row{
    return [self recommendModelForIndex:row].linkObject.thumb.tr_URL;
}
- (NSString *)recommendNickForIndex:(NSInteger)row{
    return [self recommendModelForIndex:row].linkObject.nick;
}
- (NSString *)recommendViewNumberForIndex:(NSInteger)row{
    NSString *views = [self recommendModelForIndex:row].linkObject.view;
    if (views.doubleValue >= 10000) {
        views = [NSString stringWithFormat:@"%.2f万", views.doubleValue/10000.0];
    }
    return views;
}
- (NSURL *)recommendVideoURLForIndex:(NSInteger)row{
    return [self recommendModelForIndex:row].linkObject.uid.tr_videoURL;
}


/*======= 其他部分 =======*/
- (IntroLinkModel *)linkModelForIndexPath:(NSIndexPath *)indexPath{
    NSArray *tmpMobileLinks = self.linkList[indexPath.section];
    IntroMobileModel *mlModel = tmpMobileLinks[indexPath.row];
    return mlModel.linkObject;
}

- (NSInteger)linkNumber{
    return self.linkList.count;
}

- (NSInteger)linkNumberForSection:(NSInteger)section{
    NSArray *tmpMobileLinks = self.linkList[section];
    return tmpMobileLinks.count;
}

- (NSURL *)linkIconURLForIndexPath:(NSIndexPath *)indexPath{
    return [NSURL URLWithString:[self linkModelForIndexPath:indexPath].thumb];
}
- (NSString *)linkTitleForIndexPath:(NSIndexPath *)indexPath{
    return [self linkModelForIndexPath:indexPath].title;
}
- (NSString *)linkNickForIndexPath:(NSIndexPath *)indexPath{
    return [self linkModelForIndexPath:indexPath].nick;
}
- (NSString *)linkViewForIndexPath:(NSIndexPath *)indexPath{
    NSString *views = [self linkModelForIndexPath:indexPath].view;
    if (views.doubleValue >= 10000) {
        views = [NSString stringWithFormat:@"%.2f万", views.doubleValue/10000.0];
    }
    return views;
}
- (NSURL *)linkVideoURLForIndexPath:(NSIndexPath *)indexPath{
    return [self linkModelForIndexPath:indexPath].uid.tr_videoURL;
}
- (NSString *)linkCategoryNameForIndexPath:(NSIndexPath *)indexPath{
    return [self linkModelForIndexPath:indexPath].categoryName;
}
- (NSString *)linkSlugForIndexPath:(NSIndexPath *)indexPath{
    return [self linkModelForIndexPath:indexPath].categorySlug;
}

- (NSString *)linkCategoryNameForSection:(NSInteger)section{
    return self.linkList[section].firstObject.linkObject.categoryName;
}



@end













