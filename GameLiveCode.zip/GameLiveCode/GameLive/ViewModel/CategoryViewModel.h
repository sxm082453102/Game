//
//  CategoryViewModel.h
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>



#import "TRLiveNetManager.h"
//属性和方法要根据UI和接口来定
@interface CategoryViewModel : NSObject
//UI
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)iconURLForIndex:(NSInteger)index;
- (NSString *)titleForIndex:(NSInteger)index;
- (NSString *)slugForIndex:(NSInteger)index;

//接口
@property (nonatomic) NSArray<CategoryModel *> *categories;
//这个方法是在view层调用的, 不需要让view层知道model层的东西, 所以block的参数不用填model
- (void)getDataCompletionHandler:(void(^)(NSError *error))completionHandler;

@end












