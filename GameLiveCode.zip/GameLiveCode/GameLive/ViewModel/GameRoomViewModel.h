//
//  RoomViewModel.h
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TRLiveNetManager.h"

typedef NS_ENUM(NSUInteger, RequestMode) {
    RequestModeRefresh,
    RequestModeMore,
};

@interface GameRoomViewModel : NSObject
//根据UI

- (NSURL *)videoURLForIndex:(NSInteger)index;

@property (nonatomic, readonly) NSInteger rowNumber;
/** 图片地址, 注意String-> URL */
- (NSURL *)iconURLForIndex:(NSInteger)index;
/** 房间名 */
- (NSString *)titleForIndex:(NSInteger)index;
/** 主播名 */
- (NSString *)nameForIndex:(NSInteger)index;
/** 观看人数, 注意 超过10000 -> ?.?万 */
- (NSString *)viewsForIndex:(NSInteger)index;

//根据接口
@property (nonatomic) NSInteger pageNum;
@property (nonatomic) NSMutableArray<GameRoomDataModel *> *roomList;

- (void)getGameRoomModeWithRequestMode:(RequestMode)requestMode slug:(NSString *)slug completionHandler:(void(^)(NSError *error))completionHandler;

@end










