//
//  CategoryViewModel.m
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "CategoryViewModel.h"

@implementation CategoryViewModel
- (void)getDataCompletionHandler:(void (^)(NSError *))completionHandler{
    [TRLiveNetManager getCategoriesCompletionHandler:^(NSArray<CategoryModel *> *model, NSError *error) {
        self.categories = model;
        !completionHandler ?: completionHandler(error);
    }];
}

- (NSString *)slugForIndex:(NSInteger)index{
    return self.categories[index].slug;
}

- (NSInteger)rowNumber{
    return self.categories.count;
}

- (NSURL *)iconURLForIndex:(NSInteger)index{
    return [NSURL URLWithString:self.categories[index].thumb];
}
- (NSString *)titleForIndex:(NSInteger)index{
    return self.categories[index].name;
}


@end













