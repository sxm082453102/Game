//
//  ViewController.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"
#import "TRLiveNetManager.h"
@interface ViewController ()
@property (nonatomic) UIButton *button;
@end
@implementation ViewController
#pragma mark - 方法

#pragma mark - 懒加载
//button是用于保存按钮的指针, 存储属性
- (UIButton *)button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeSystem];
        [self.view addSubview:_button];
        //按钮100宽 60高, 在屏幕中心
        [_button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.equalTo(CGSizeMake(100, 60));
            make.center.equalTo(0);
        }];
        _button.backgroundColor = [UIColor purpleColor];
        //BlocksKit的方法都是以bk_开头的
        [_button bk_addEventHandler:^(id sender) {
            NSLog(@"...");
       
            [self.view showBusyHUD];
            [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
                [self.view hideBusyHUD];
            } repeats:NO];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}
#pragma mark - 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    [self button];
    //获知当前网络状态
    BOOL onLine = kAppDelegate.isOnLine;
    NSLog(@"当前%@", onLine?@"有网络":@"离线状态");
    
    //self.view.backgroundColor = [UIColor colorWithRed:160/255.0 green:170/255.0 blue:3/255.0 alpha:1.0];
    self.view.backgroundColor = kRGBColor(160, 170, 3, 1.0);
    [TRLiveNetManager getCategoriesCompletionHandler:nil];
    [TRLiveNetManager getVideosCompletionHandler:^(VideoModel *model, NSError *error) {
        
    }];
    
    [TRLiveNetManager getADSlotCompletionHandler:^(ADSlotModel *model, NSError *error) {
        NSLog(@"");
    }];
    
    [TRLiveNetManager getFastNewsCompletionHandler:^(FastNewsModel *model, NSError *error) {
        NSLog(@"dd");
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
