//
//  Tool.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool : NSObject

/** 播放URL视频 */
+ (void)playVideoInURL:(NSURL *)videoURL;

/** 用于为某一个视图控制器添加返回按钮的 */
+ (void)addBackItemToVC:(UIViewController *)vc;

/** 搜索按钮 */
+ (void)addSearchItemToVC:(UIViewController *)vc clickedHandler:(void(^)())handler;
@end











