//
//  Tool.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "Tool.h"
@import AVFoundation;
@import AVKit;

@implementation Tool
/*
 MPMoviePlayerController
 AVKit
 */
+ (void)playVideoInURL:(NSURL *)videoURL{
    AVPlayerViewController *vc = [AVPlayerViewController new];
    AVPlayer *player = [[AVPlayer alloc] initWithURL:videoURL];
    vc.player = player;
    [player play];
    [kAppDelegate.window.rootViewController presentViewController:vc animated:YES completion:nil];
}

+ (void)addBackItemToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 50, 44);
    [btn setImage:[UIImage imageNamed:@"返回_默认"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"返回_按下"] forState:UIControlStateHighlighted];
    [btn bk_addEventHandler:^(id sender) {
        [vc.navigationController popViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    //调整间距
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -15;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,backItem];
}

+ (void)addSearchItemToVC:(UIViewController *)vc clickedHandler:(void (^)())handler{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 50, 44);
    [btn setImage:[UIImage imageNamed:@"搜索_默认"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"搜索_按下"] forState:UIControlStateHighlighted];
    [btn bk_addEventHandler:^(id sender) {
        !handler ?: handler();
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *searchItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    UIBarButtonItem *spaceItem =
    [[UIBarButtonItem alloc]
     initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
     target:nil
     action:nil];
    spaceItem.width = -15;
    vc.navigationItem.rightBarButtonItems = @[spaceItem, searchItem];
}

@end









