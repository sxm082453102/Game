//
//  IntroSectionHeaderView.m
//  GameLive
//
//  Created by shixiaomin on 16/4/12.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "IntroSectionHeaderView.h"

@implementation IntroSectionHeaderView

- (IBAction)moreBtnClicked:(id)sender {
    !_clickedHandler ?: _clickedHandler();
}
- (IBAction)changeBtnClicked:(id)sender {
    !_clickedHandler ?: _clickedHandler();
}

- (void)addClickedHandler:(void (^)())handler{
    self.clickedHandler = handler;
}


- (void)awakeFromNib {
    // Initialization code
}

@end
