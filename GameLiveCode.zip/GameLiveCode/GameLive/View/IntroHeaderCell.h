//
//  IntroHeaderCell.h
//  GameLive
//
//  Created by shixiaomin on 16/4/12.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"
#import "IntroViewModel.h"
@interface IntroHeaderCell : UICollectionViewCell<iCarouselDelegate, iCarouselDataSource>

@property (weak, nonatomic) IBOutlet iCarousel *starIC;
@property (weak, nonatomic) IBOutlet iCarousel *adIC;
@property (weak, nonatomic) IBOutlet UILabel *titleLb;
@property (weak, nonatomic) IBOutlet UIPageControl *pageC;
@property (nonatomic) IntroViewModel *introVM;


@end












