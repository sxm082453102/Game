//
//  RoomCell.h
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RoomCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLb;
@property (weak, nonatomic) IBOutlet UIImageView *iconIV;
@property (weak, nonatomic) IBOutlet UILabel *nickLb;
@property (weak, nonatomic) IBOutlet UILabel *viewsLb;

@end












