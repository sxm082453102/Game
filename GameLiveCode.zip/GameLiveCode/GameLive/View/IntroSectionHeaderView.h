//
//  IntroSectionHeaderView.h
//  GameLive
//
//  Created by shixiaomin on 16/4/12.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IntroSectionHeaderView : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UILabel *titleLb;
@property (weak, nonatomic) IBOutlet UIButton *moreBtn;
@property (weak, nonatomic) IBOutlet UIButton *changeBtn;
- (void)addClickedHandler:(void(^)())handler;
@property (nonatomic, copy) void(^clickedHandler)();

@end










