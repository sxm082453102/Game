//
//  IntroHeaderCell.m
//  GameLive
//
//  Created by shixiaomin on 16/4/12.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "IntroHeaderCell.h"

@implementation IntroHeaderCell

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    if (carousel == _adIC) {
        return self.introVM.indexNumber;
    }else{
        return self.introVM.starNumber;
    }
    return 0;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if (carousel == _adIC) {
        if (!view) {
            view = [[UIImageView alloc] initWithFrame:carousel.bounds];
        }
        [((UIImageView *)view) setImageWithURL:[self.introVM indexIconForIndex:index]];
        return view;
    }else{
        if (!view) {
            view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 80, 110)];
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
            [view addSubview:imageView];
            [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerX.equalTo(0);
                make.size.equalTo(CGSizeMake(60, 60));
                make.top.equalTo(10);
            }];
            imageView.tag = 100;
            imageView.layer.cornerRadius = 30;
            imageView.layer.masksToBounds = YES;
            UILabel *lb = [UILabel new];
            [view addSubview:lb];
            [lb mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.right.equalTo(0);
                make.top.equalTo(imageView.mas_bottom).equalTo(15);
            }];
            lb.textAlignment = NSTextAlignmentCenter;
            lb.tag = 200;
        }
        UIImageView *iv = (UIImageView *)[view viewWithTag:100];
        UILabel *lb = (UILabel *)[view viewWithTag:200];
        [iv setImageWithURL:[self.introVM starIconURLForIndex:index]];
        lb.text = [self.introVM starNameForIndex:index];
        return view;
    }
}

- (void)setIntroVM:(IntroViewModel *)introVM{
    _introVM = introVM;
    self.pageC.numberOfPages = [self.introVM indexNumber];
    [_starIC reloadData];
    [_adIC reloadData];
}

- (void)awakeFromNib {
    // Initialization code
    _adIC.delegate = self;
    _adIC.dataSource = self;
    _adIC.scrollSpeed = 0.1;
    [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
        [_adIC scrollToItemAtIndex:_adIC.currentItemIndex +1 animated:YES];
    } repeats:YES];
    
    _starIC.delegate = self;
    _starIC.dataSource = self;
    _starIC.autoscroll = YES;
}
//通过协议允许循环滚动
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if (option == iCarouselOptionWrap) {
        value = YES;
    }
    return value;
}
//当滚动翻页时
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    if (carousel == _adIC) {
        self.pageC.currentPage = carousel.currentItemIndex;
        self.titleLb.text = [self.introVM indexTitleForIndex:carousel.currentItemIndex];
    }
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    if (carousel == _adIC) {
        [Tool playVideoInURL:[self.introVM indexURLForIndex:index]];
    }else{
        [Tool playVideoInURL:[self.introVM starVideoURLForIndex:index]];
    }
}

@end












