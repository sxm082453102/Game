//
//  UIScrollView+Refresh.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MJRefresh.h"



@interface UIScrollView (Refresh)
/** 添加头部刷新 */
- (void)tr_addHeaderRefresh:(void(^)())block;
- (void)tr_beginHeaderRefresh;
- (void)tr_endHeaderRefresh;

- (void)tr_addFooterAutoRefresh:(void(^)())block;
- (void)tr_addFooterBackRefresh:(void(^)())block;
- (void)tr_beginFooterRefresh;
- (void)tr_endFooterRefresh;

@end













