//
//  UIView+HUD.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface UIView (HUD)

- (void)showWarning:(NSString *)words;

/** 显示繁忙提示 */
- (void)showBusyHUD;
/** 隐藏繁忙提示 */
- (void)hideBusyHUD;
@end









