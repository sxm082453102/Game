//
//  NSString+TR.m
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "NSString+TR.h"

@implementation NSString (TR)
- (NSURL *)tr_URL{
    return [NSURL URLWithString:self];
}

- (NSURL *)tr_videoURL{
    return [NSString stringWithFormat:@"http://hls.quanmin.tv/live/%@/playlist.m3u8", self].tr_URL;
}

@end











