//
//  NSObject+Parse.m
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "NSObject+Parse.h"

@implementation NSObject (Parse)

+ (NSDictionary *)modelCustomPropertyMapper {
    return nil;
}
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return nil;
}
+(id)parseJSON:(id)json{
    if ([json isKindOfClass:[NSDictionary class]]) {
        return [self modelWithJSON:json];
    }
    if ([json isKindOfClass:[NSArray class]]) {
        return [NSArray modelArrayWithClass:[self class] json:json];
    }
    //既不是字典 也不是数组
    return [self modelWithJSON:json];
}

@end












