//
//  NSObject+Parse.h
//  GameLive
//
//  Created by shixiaomin on 16/4/6.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YYKit.h>

@interface NSObject (Parse)

+ (id)parseJSON:(id)json;
//主要是为了出代码提示
+ (NSDictionary *)modelCustomPropertyMapper;
+ (NSDictionary *)modelContainerPropertyGenericClass;
@end












