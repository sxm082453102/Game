//
//  AppDelegate+Custom.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "AppDelegate+Custom.h"

@implementation AppDelegate (Custom)
- (void)setupGlobalConfig{
    //监听当前网络状态
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"Reachability:%@", AFStringFromNetworkReachabilityStatus(status));
    }];
    //启动监听
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    
    //统一配置
    [UINavigationBar appearance].barTintColor = [UIColor redColor];
    //更改状态栏和题目颜色为白色
    [UINavigationBar appearance].barStyle = UIBarStyleBlackOpaque;
    self.window.tintColor = [UIColor redColor];
    
}
- (AFNetworkReachabilityStatus)netStatus{
    return [AFNetworkReachabilityManager sharedManager].networkReachabilityStatus;
}
- (BOOL)isOnLine{
    switch (self.netStatus) {
        case AFNetworkReachabilityStatusUnknown:
        case AFNetworkReachabilityStatusNotReachable:
            return NO;
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
        case AFNetworkReachabilityStatusReachableViaWWAN:
            return YES;
    }
}

@end











