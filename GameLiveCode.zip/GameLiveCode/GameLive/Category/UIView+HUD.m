//
//  UIView+HUD.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "UIView+HUD.h"

#define kWarningDuration   1.5
#define kTimeOutDuration   30

@implementation UIView (HUD)

- (void)showWarning:(NSString *)words{
    //为了避免重复提示的重合现象
    //为了防止调用此方法的线程是子线程,导致项目崩溃, 所以强制让下方代码在主线程中执行
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self animated:NO];
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.labelText = words;
        [hud hide:YES afterDelay:kWarningDuration];
    });
    
}

- (void)showBusyHUD{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self animated:NO];
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self animated:YES];
        hud.mode = MBProgressHUDModeCustomView;
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
        NSArray *imageNames = @[@"00", @"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10", @"11"];
        NSMutableArray<UIImage *> *imgs = [NSMutableArray new];
        for (NSString *imageName in imageNames) {
            [imgs addObject:[UIImage imageNamed:imageName]];
        }
        imageView.animationImages = imgs;
        hud.customView = imageView;
        imageView.animationDuration = 1.0;
        [imageView startAnimating];
        hud.color = [UIColor clearColor];
        [hud hide:YES afterDelay:kTimeOutDuration];
    });
}
- (void)hideBusyHUD{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self animated:YES];
    });
}


@end






