//
//  NSString+TR.h
//  GameLive
//
//  Created by shixiaomin on 16/4/11.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (TR)
//一般来说,分类添加的方法要加一个前缀, 防止跟系统原生的方法重名
@property (nonatomic, readonly) NSURL *tr_URL;

@property (nonatomic, readonly) NSURL *tr_videoURL;
@end











