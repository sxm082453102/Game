//
//  AppDelegate+System.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (System)

@end
