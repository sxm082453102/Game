//
//  NSObject+Networking.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "NSObject+Networking.h"

static AFHTTPSessionManager *manager = nil;


@implementation NSObject (Networking)

+ (AFHTTPSessionManager *)sharedAFNetManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
       
        manager = [AFHTTPSessionManager manager];
        //超时的时间,默认是60
        manager.requestSerializer.timeoutInterval = 30;
        //响应的内容类型
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", nil];
    });
    return manager;
}

+ (id)GET:(NSString *)path parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))downloadProgress completionHandler:(void (^)(id, NSError *))completionHandler{
    
        return [[self sharedAFNetManager] GET:path parameters:parameters progress:downloadProgress success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completionHandler(responseObject, nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completionHandler(nil, error);
    }];
}

+ (id)POST:(NSString *)path parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))downloadProgress completionHandler:(void (^)(id, NSError *))completionHandler{
   
    return [[self sharedAFNetManager] POST:path parameters:parameters progress:downloadProgress success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completionHandler(responseObject, nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completionHandler(nil, error);
    }];
}

@end










