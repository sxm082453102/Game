//
//  AppDelegate+Custom.h
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "AppDelegate.h"
#import <AFNetworkReachabilityManager.h>

@interface AppDelegate (Custom)

/** 当前是否在线, 此属性是计算属性 */
@property (nonatomic, readonly, getter=isOnLine) BOOL onLine;

/** 当前网络状态:无网络,未知,WiFi,手机网络2G,3G,4G */
@property (nonatomic, readonly) AFNetworkReachabilityStatus netStatus;
/** 全局的一些配置 */
- (void)setupGlobalConfig;
@end










