//
//  AppDelegate.m
//  GameLive
//
//  Created by shixiaomin on 15/12/5.
//  Copyright © 2015年 shixiaomin. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+System.h"
#import <SMS_SDK/SMSSDK.h>

@interface AppDelegate ()
@end
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self setupGlobalConfig];
    //初始化应用，appKey和appSecret从后台申请得
    [SMSSDK registerApp:@"104b1a1b239c0"
        withSecret:@"44d7b4b687218177ecf039149215bbf5"];
    //AppKey:注册的appKey，详细见下面注释。
    //apnsCertName:推送证书名(不需要加后缀)，详细见下面注释。
   
    [[EaseSDKHelper shareHelper]
     easemobApplication:application
didFinishLaunchingWithOptions:launchOptions
     appkey:@"736907613#gamelive"
     apnsCertName:nil
     otherConfig:@{kSDKConfigEnableConsoleLogger:[NSNumber numberWithBool:YES]}];
    
    
    return YES;
}
@end









